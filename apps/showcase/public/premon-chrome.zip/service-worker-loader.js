import './assets/index.ts-6dac5mvi.js';
